def imp():
    q = 1
    while q <= 10:
        w = 1
        while w <= 10:
            print w
            w = w+1
        q = q+1
imp()
