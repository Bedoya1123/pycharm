#!/usr/bin/env python
#-*- coding: utf-8 -*-

def caracter (a):

    for i in a:

        print i*" / "


caracter ([4,9,7])