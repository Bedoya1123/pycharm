def max (c,b):
    if c>b:
        print c
    else :
        print b
max(5,3)
