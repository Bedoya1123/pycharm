def longi (g):
    d=0
    for i in g:
        d = d+1
    return d

print longi ("cristian" )