def max (c,d,e):
    if c > d and c > e:
        print c
    elif d > c and d >e:
        print d
    elif e >c and e > d :
        print e

max (2,4,3)