def mul(n):
    for i in range(1,11):
        q= n*i
        print (str(n) +" X "+str (i) +" = " + str (q))
a = input(" Ingrese el numero de la tabla que desea saber su multiplo ")
mul(a)
