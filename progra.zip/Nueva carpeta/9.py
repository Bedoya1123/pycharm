#!/usr/bin/env python
#-*- coding: utf-8 -*-

def mul (a,b):
    z= a*b
    print z

q = raw_input("ingrese caracter")
c = input("ingrese numero")
mul (q,c)
