def sum (c):
    s = 0
    for i in c:
        s= s+i
    return s

def multi (d):
    x =1
    for i in d:
        x = x*i
    return x

print (sum ([1,2,3,4]))
print (multi ([1,2,3,4]))
